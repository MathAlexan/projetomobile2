import React, {useState} from 'react';
import {Button, StyleSheet,Text,TextInput,View} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

export default function AdicionarItem({ funcao }) {
  const [texto, setTexto] = useState('');

  const pegarMudanca = (val) => {
    setTexto(val)
  }

  const adicionarPedido = () => {
    funcao(texto);
    setTexto(''); // Limpar o texto após adicionar o pedido
  }

  return (
    <View style={styles.cabecalho}>
      <TextInput
        style={styles.input}
        placeholder="Novo item..."
        onChangeText={pegarMudanca}
        value={texto} // Definir o valor do TextInput como o estado "texto"
      />
      <Button
        onPress={adicionarPedido}
        title="Adicionar Pedido"
        color='#FF69B4'
      />
    </View>
  )
}

const styles = StyleSheet.create({
  input:{
    marginBottom:10,
    paddingHorizontal:8,
    paddingVertical:6,
    borderBottomWidth:1,
    borderBottomColor: '#ddd',  
    },
});