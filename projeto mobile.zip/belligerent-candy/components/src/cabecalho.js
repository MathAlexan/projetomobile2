import React from "react"
import {StyleSheet, Text, View} from "react-native";
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

export default function Cabecalho() {
  return (
    <View style={styles.cabecalho}>
    <Text style={styles.titulo}>itens</Text>
    </View>
  )
}

const styles = StyleSheet.create({
  cabecalho: {
    height:80,
    paddingTop:38,
    backgroundColor:'#FF69B4',
  },

  titulo: {
    textAlign: "center",
    color: "#fff",
    fontSize:20,
    fontWeight: "bold",
  },
});