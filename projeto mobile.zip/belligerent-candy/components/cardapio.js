import React, { useState } from "react";
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Cabecalho from "./src/cabecalho";
import NovosItens from "./src/NovosItens";
import AdicionarItem from "./src/adicionarItem";

export default function App() {
  const [lista, setLista] = useState([
  ]);

  const apertarItem = (key) => {
    setLista(prevLista => prevLista.filter(item => item.key !== key));
  };

  const submeterInformacao = (texto) => {
    setLista(prevLista => [
      { texto: texto, key: Math.random().toString() },
      ...prevLista
    ]);
  };

  return (
    <View style={styles.container}>
      <Cabecalho />
      <View style={styles.conteudo}>
        <AdicionarItem funcao={submeterInformacao} />
        <View style={styles.estiloLista}>
          <FlatList
            data={lista}
            renderItem={({ item }) => (
              <NovosItens props={item} funcao={apertarItem} />
            )}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e0e5e5',
  },
  conteudo: {
    padding: 40,
  },
});
