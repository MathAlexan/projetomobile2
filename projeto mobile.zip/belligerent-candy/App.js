import React, { useState } from "react";
import Ionicons from "@expo/vector-icons/Ionicons";
import { AntDesign } from '@expo/vector-icons';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, Alert, ScrollView, FlatList } from "react-native";
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Cardapio from "./components/cardapio";
import { useNavigation } from '@react-navigation/native';


const Stack = createNativeStackNavigator();

const Login = ({ navigation }) => {
  const onPressAcessar = () => {
    Alert.alert('Bem Vindo!', `${nome}`);
    navigation.navigate('ReservaMesas');
  };
  
  const onPressEsqueceuASenha = () => {
  };

  const onPressCadastrar = () => {
  };

  const [nome, setNome] = useState("");
  const [cpf, setCpf] = useState("");

  return (
    <View style={styles.container}>
      <Text>Login</Text>

      <View style={styles.inputView}>
        <Ionicons name="person" size={24} color="black" />
        <TextInput
          style={styles.inputText}
          placeholder=" Nome Completo"
          placeholderTextColor="#003f5c"
          onChangeText={(text) => setNome(text)}
        />
      </View>

      <View style={styles.inputView}>
        <AntDesign name="idcard" size={24} color="black"  />
        <TextInput
          style={styles.inputText}
          placeholder=" CPF"
          placeholderTextColor="#003f5c"
          maxLength={11}
          keyboardType="numeric"
          onChangeText={(text) => setCpf(text)}
        />
      </View>

      <TouchableOpacity onPress={onPressEsqueceuASenha}>
        <Text style={styles.forgotAndSignUpText}>Esqueceu a senha?</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={onPressAcessar} style={styles.loginButton}>
        <Text style={styles.loginText}>Acessar</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={onPressCadastrar}>
        <Text style={styles.forgotAndSignUpText}>Criar Conta</Text>
      </TouchableOpacity>
    </View>
  );
};

const ReservaMesas = () => {
  const navigation = useNavigation();
  const [mesas, setMesas] = useState([
    {
      nome: 'Mesa 1',
      key: 1,
      descricao:
        'Mesa disponível na quinta-feira às 15:00 com capacidade de 4 pessoas',
    },
    {
      nome: 'Mesa 2',
      key: 2,
      descricao:
        'Mesa disponível na sexta-feira às 18:00 com capacidade de 6 pessoas',
    },
    {
      nome: 'Mesa 3',
      key: 3,
      descricao:
        'Mesa disponível no domingo às 12:00 com capacidade de 4 pessoas',
    },
    {
      nome: 'Mesa 4',
      key: 4,
      descricao:
        'Mesa disponível na segunda-feira às 16:00 com capacidade de 2 pessoas',
    },
    {
      nome: 'Mesa 5',
      key: 5,
      descricao:
        'Mesa disponível na terça-feira às 20:00 com capacidade de 6 pessoas',
    },
    {
      nome: 'Mesa 6',
      key: 6,
      descricao:
        'Mesa disponível na quarta-feira às 14:00 com capacidade de 8 pessoas',
    },
    {
      nome: 'Mesa 7',
      key: 7,
      descricao:
        'Mesa disponível na quinta-feira às 17:00 com capacidade de 4 pessoas',
    },
    {
      nome: 'Mesa 8',
      key: 8,
      descricao:
        'Mesa disponível na sexta-feira às 19:00 com capacidade de 6 pessoas',
    },
    {
      nome: 'Mesa 9',
      key: 9,
      descricao:
        'Mesa disponível no sábado às 18:00 com capacidade de 8 pessoas',
    },
    {
      nome: 'Mesa 10',
      key: 10,
      descricao:
        'Mesa disponível no domingo às 13:00 com capacidade de 4 pessoas',
    },
  ]);

  const apertarBotao = (boxItem) => {
  console.log(boxItem.descricao);
  Alert.alert(
    boxItem.nome,
    boxItem.descricao,
    [
      {
        text: "Reservar",
        onPress: () => navigation.navigate('Cardapio'), // Nav 3
      },
      { text: "Cancelar", onPress: () => console.log("Botão Cancelar pressionado") }
    ]
  );
};

  return (
    <ScrollView>
      <View style={styles.container}>
        <View style={styles.boxtitulo}>
          <Text style={styles.title}>Escolha sua Mesas</Text>
        </View>

        <FlatList
          numColumns={2}
          keyExtractor={(item) => item.nome}
          data={mesas}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => apertarBotao(item)}>
              <View style={styles.boxItem}>
                <Text style={styles.itemText}>{item.nome}</Text>
              </View>
            </TouchableOpacity>
          )}
        />
      </View>
    </ScrollView>
  );
};

const App = () => {  // nav ordem
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Escolher Mesa" component={ReservaMesas} />
        <Stack.Screen name="Cardapio" component={Cardapio} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  inputView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: 300,
    height: 40,
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 10,
    marginVertical: 10,
  },
  inputText: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
  },
  forgotAndSignUpText: {
    fontSize: 14,
    marginTop: 10,
  },
  loginButton: {
    backgroundColor: '#DDA0DD',
    borderColor: "black",
    alignItems: "center",
    justifyContent: "center",
    width: 200,
    height: 50,
    marginTop: 20,
    marginBottom: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  loginText: {
    fontWeight: "bold",
    color: 'black',
    fontSize: 16,
  },
  boxtitulo: {
    marginTop: 40,
  },
  title: {
    marginTop: 2,
    textAlign: "center",
    fontWeight: "bold",
    fontSize: 40,
    color: "#8B008B",
    textShadowRadius: 1,
    textShadowOffset: { width: 2, height: 2 },
  },
  boxItem: {
    justifyContent: "center",
    alignItems: 'center',
    backgroundColor: "#FF69B4",
    borderColor: "black",
    marginTop: 30,
    marginHorizontal: 5,
    width: 160,
    height: 110,
    padding: 20,
    borderRadius: 10,
    borderWidth: 2,
  },
  itemText: {
    fontSize: 20,
    fontWeight: "bold",
  },
});

export default App;
